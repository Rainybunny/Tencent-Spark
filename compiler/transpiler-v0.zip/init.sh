#!/bin/bash

g++ mapping_routing.cpp -o mapping -O2
